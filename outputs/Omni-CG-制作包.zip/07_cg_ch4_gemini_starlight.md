# cg_ch4_gemini_starlight

- assets/sprites/gemini-summer-front.webp
- assets/bg/bg_twinstar_roof_sunset.webp
- assets/bg/cg_confession_gemini.webp

## Static Prompt

Masterpiece commercial anime visual novel romantic event CG illustration, 16:9 widescreen, intimate first-person POV close-up matching the exact art style of cg_confession_gemini.webp. On the rain-slicked academy observatory rooftop at violet-indigo twilight after rain matching bg_twinstar_roof_sunset.webp, wet wooden deck mirroring glowing four-pointed star fairy lights, a vintage brass armillary sphere gleaming softly in the background, and the first bright stars emerging over the distant ocean bay. Matching exact character design and summer outfit from gemini-summer-front.webp: periwinkle-to-pink high twin-tail cat-girl Gemini with fluffy cat ears, curved ahoge, iridescent four-pointed star hairclip, strictly preserving heterochromia (viewer-left eye rose-pink, viewer-right eye glowing amber-gold), wearing her cropped white short-sleeve sailor blouse with pastel-violet trim and star brooch, and white pleated mini skirt. Beneath a clear transparent vinyl umbrella dotted with tiny dew droplets, she nestles closely against the viewer's shoulder (only viewer's dark jacket shoulder edge visible at far left), leaning her head affectionately while gazing up with both heterochromatic eyes sparkling in blissful harmony and a sweet warm blush, her hand holding a hand-drawn star chart against her chest.

## Motion Prompt

Dreamy twilight anime loop, 5 seconds, subtle floating camera breathe: glowing four-pointed star fairy lights twinkle gently in the bokeh background and wet deck reflections, tiny clear raindrops glisten on the transparent umbrella overhead, Gemini's twin-tails and cat ears sway softly in the evening rooftop breeze, shimmering starlight reflects in her rose-pink and gold heterochromatic eyes, silent video.
