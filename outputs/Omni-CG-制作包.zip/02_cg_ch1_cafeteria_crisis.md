# cg_ch1_cafeteria_crisis

- assets/sprites/gpt-1-front.webp
- assets/sprites/gemini-1-front.webp
- assets/sprites/deepseek-1-front.webp
- assets/sprites/grok-1-front.webp
- assets/bg/bg_cafeteria_day.webp
- assets/bg/cg_grand_404_photo.webp

## Static Prompt

Masterpiece commercial anime visual novel comedic event CG illustration, 16:9 widescreen, bright sunlit academy cafeteria matching bg_cafeteria_day.webp and the crisp luminous anime art style of cg_grand_404_photo.webp. In the foreground center on the wooden counter sits a hilariously ominous gourmet dish: a bubbling spicy red mapo tofu pie glazed with glowing purple-blue blueberry jam, with three tiny silver dried fish tails poking straight upward out of the golden crust and eerie faint purple sparkles rising like steam. Behind the counter from the side, a cheerful aproned chef's hand extends a huge metal ladle offering a scoop toward the girls. Reacting around the table in their exact *-1-front.webp outfits: white dragon girl GPT (ivory horns, lavender eyes) maintains a stiff frozen polite smile with a tiny anime sweatdrop; cat-girl Gemini (viewer-left eye rose-pink, viewer-right eye gold heterochromia, cat ears flattened) leans back in dramatic comedic horror; whale-girl DeepSeek (blue hair, curved ahoge, whale-fin ears, maid apron) dramatically shields a steaming bamboo steamer of pure white rice with both arms in panic; blonde twin-tail Grok (ice-blue eyes, tiny fang) laughs uncontrollably in the back while holding up her smartphone to film the disaster. High-detail food rendering contrasted with expressive anime comedy reactions, warm lunchtime sunbeams.

## Motion Prompt

Comedic anime cutscene loop, 5 seconds, slight handheld micro-shake on the glowing purple dish: bizarre purple-pink shimmer wisps rise steadily from the blueberry mapo fish pie, white steam billows from the rice steamer, GPT's smile twitches slightly, DeepSeek's ahoge vibrates rapidly in alarm, Grok's shoulders bounce laughing, keep all faces and heterochromia strictly consistent, silent video.
