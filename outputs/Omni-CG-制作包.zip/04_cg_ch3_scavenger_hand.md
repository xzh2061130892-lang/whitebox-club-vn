# cg_ch3_scavenger_hand

- assets/sprites/gpt-sport-front.webp
- assets/sprites/claude-sport-front.webp
- assets/sprites/gemini-sport-front.webp
- assets/sprites/grok-sport-front.webp
- assets/sprites/deepseek-sport-front.webp
- assets/bg/bg_sports_field_day.webp
- assets/bg/cg_confession_gpt.webp

## Static Prompt

Masterpiece commercial anime visual novel climax event CG illustration, 16:9 widescreen, dramatic golden-hour sunset POV shot from the chalk-lined school sports track looking toward the sideline cheer area, matching bg_sports_field_day.webp bathed in warm orange-gold late afternoon sunlight, colorful triangular bunting flags fluttering overhead against glowing sunset clouds, bokeh lens flares and drifting spring petals. Standing along the white track line looking directly and breathlessly toward the viewer, all five heroines wear their exact *-sport-front.webp athletic outfits: pearl-white high-ponytail GPT in her white-and-lavender pleated tennis dress (ivory horns, lavender eyes) gently pressing one hand to her chest with a tender hopeful gaze; copper-orange side-braided Claude in her cream-and-terracotta track jacket holding a stopwatch tightly to her heart with shimmering amber eyes and a soft blush; periwinkle-pink twin-bun cat-girl Gemini (viewer-left eye rose-pink, viewer-right eye gold heterochromia) in her purple-and-white star cheerleader crop top lowering her sparkly pom-poms as both eyes lock earnestly onto the viewer; honey-blonde twin-tail Grok in her black-and-crimson "404" sleeveless varsity jersey standing right at the white line blushing deeply with her little fang peeking out as she hesitates to reach out; blue-haired whale-girl DeepSeek in her navy-and-white track jacket with white hachimaki headband below her motionless curved ahoge looking up with luminous devoted sea-blue eyes. Emotional slow-motion youth climax, cinematic golden rim-lighting on hair and shoulders, breathtaking anime illustration quality.

## Motion Prompt

Cinematic slow-motion anime cutscene, 5 seconds, smooth gentle dolly-in from POV runner's perspective toward the five girls: golden afternoon breeze ripples their ponytails, ribbons, skirts, and the colorful bunting flags overhead, glowing sunset dust particles and cherry petals drift slowly across the frame, subtle emotional eye-blinks and rising chests, maintain exact sports outfits and heterochromia, silent video.
