# cg_ch2_lodge_candlelight

- assets/sprites/grok-1-front.webp
- assets/sprites/claude-1-front.webp
- assets/sprites/gpt-1-front.webp
- assets/sprites/gemini-1-front.webp
- assets/sprites/deepseek-1-front.webp
- assets/bg/bg_camp_lodge_night.webp
- assets/bg/cg_confession_claude.webp

## Static Prompt

Masterpiece commercial anime visual novel atmospheric event CG illustration, 16:9 widescreen, intimate warm amber candlelight and glowing fireplace illumination inside the rainy blackout wooden camp lodge matching bg_camp_lodge_night.webp, raindrops streaking down the dark indigo glass sliding doors overlooking misty ocean night in the background. All five heroines in their exact *-1-front.webp outfits sit close together on floor cushions around the low wooden table lit by glass jar candles and a warm camping lantern: center-left, honey-blonde twin-tail Grok (ice-blue eyes, cute single fang, bat-wing bows) leans forward blushing shyly while telling a gentle legend with one hand gesturing near the lantern; beside her, copper-orange wavy-haired Claude (warm amber eyes, sunburst hairpiece) listens with a serene gentle smile holding a warm mug; white dragon girl GPT (ivory horns, lavender eyes) pours tea tenderly with soft golden rim-light on her silver hair; cat-girl Gemini (viewer-left eye rose-pink, viewer-right eye gold heterochromia) hugs a cushion looking wide-eyed and enchanted by the story; blue-haired whale-girl DeepSeek (curved ahoge, whale-fin ears) rests her chin on the table beside a plate of cookies with cozy sleepy eyes. Rich chiaroscuro fireplace glow, floating warm dust motes, deep heartfelt slice-of-life warmth.

## Motion Prompt

Cozy atmospheric anime loop, 5 seconds, slow gentle camera drift: crackling fireplace embers and jar candle flames flicker softly casting warm dancing light across the five girls' faces, silver rain streaks slide slowly down the dark glass windows behind them, faint steam curls from teacups, gentle breathing and slow blinking, consistent character designs, silent video.
