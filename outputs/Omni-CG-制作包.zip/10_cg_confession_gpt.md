# cg_confession_gpt

- assets/bg/cg_confession_gpt.webp

## Motion Prompt

5-second seamless anime CG loop from this exact illustration: colorful bay fireworks bloom slowly in the night sky and shimmer across the water, sea breeze gently lifts GPT's pearl-white hair strands and sheer sleeves, her pale dragon wings flutter subtly, glistening joyful tears sparkle in her lavender eyes while keeping her exact face and porcelain dress unchanged, no camera cut, silent.
