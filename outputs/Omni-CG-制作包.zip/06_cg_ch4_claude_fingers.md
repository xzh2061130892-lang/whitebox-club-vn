# cg_ch4_claude_fingers

- assets/sprites/claude-summer-front.webp
- assets/bg/bg_hydrangea_rain_walk.webp
- assets/bg/cg_confession_claude.webp

## Static Prompt

Masterpiece commercial anime visual novel romantic event CG illustration, 16:9 widescreen, intimate first-person POV medium close-up matching the exact art style of cg_confession_claude.webp. Walking side-by-side under a shared warm beige wooden-handle umbrella along a misty June rainy stone stairway framed by lush blue-violet and soft pink hydrangea blossoms matching bg_hydrangea_rain_walk.webp. Matching exact character design and summer uniform from claude-summer-front.webp: copper-orange long wavy-haired girl Claude with side braid, sunburst flower hairclip with black ribbon and cream tassels, warm amber eyes, cream short-sleeve sailor blouse with espresso trim, amber-orange plaid silk neck scarf bow, and dark brown pleated skirt. In the lower-right foreground, her slender hand shyly yet firmly intertwines fingers with the viewer's hand (protagonist's wrist/cuff edge only, face unseen); her other hand clutches a lace-trimmed handkerchief and a small blue hydrangea sprig near her chest. She glances up sideways at the viewer with a bright crimson blush across her cheeks and ears, tender determined amber eyes shining beneath the umbrella shadow, gentle translucent rain streaks and glistening wet stone reflections behind them.

## Motion Prompt

Poetic Makoto-Shinkai-style anime loop, 5 seconds, calm intimate POV camera: soft translucent rain streaks fall steadily past the beige umbrella canopy, glistening droplets drip from blooming blue hydrangea petals, Claude's copper-orange wavy hair and amber plaid scarf stir lightly in the damp breeze, subtle shy blink and gentle tightening of intertwined fingers, silent video.
