# cg_confession_grok

- assets/bg/cg_confession_grok.webp

## Motion Prompt

5-second seamless anime CG loop from this exact illustration: bay fireworks sparkle behind the marble balcony, warm lantern flames flicker softly, night breeze ripples Grok's honey-blonde twin-tails and crimson velvet skirt, subtle shy breath and glistening shimmer in her ice-blue eyes while keeping her single cute fang and hand gripping the tie completely stable, silent.
