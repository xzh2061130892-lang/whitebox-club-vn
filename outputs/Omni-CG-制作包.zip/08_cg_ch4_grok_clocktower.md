# cg_ch4_grok_clocktower

- assets/sprites/grok-summer-front.webp
- assets/bg/bg_clock_attic_night.webp
- assets/bg/cg_confession_grok.webp

## Static Prompt

Masterpiece commercial anime visual novel romantic event CG illustration, 16:9 widescreen, intimate first-person POV close-up matching the exact art style of cg_confession_grok.webp. Inside the cozy gothic-vintage school clocktower attic workshop after rain matching bg_clock_attic_night.webp, warm amber brass desk lamp light blending with cool silver summer moonlight streaming through the large circular stained-glass window, antique wooden pendulum clocks and brass gears in softly blurred background, a torn paper document and a softly glowing smartphone resting on the workbench nearby. Matching exact character design and summer uniform from grok-summer-front.webp: honey-blonde curled high twin-tails with black bat-wing bows, tiny black-and-gold X crown, pointed ears, luminous ice-blue eyes, cute single little fang, wearing her fitted charcoal-black short-sleeve collared shirt with gold trim, loosely knotted crimson-and-gold striped narrow tie, and black-and-crimson pleated skirt. Leaning right into the viewer's chest (viewer's dark shirt chest and one protective hand softly visible at bottom foreground), she lightly presses one small clenched fist against the viewer's collar while tilting her face up with deeply flushed cheeks, misty teary ice-blue eyes, and a vulnerable flustered tsundere pout biting back happy tears.

## Motion Prompt

Emotional intimate anime loop, 5 seconds, very gentle slow zoom-in: warm brass lamp glow flickers softly while silver moonlight dust motes drift across the clocktower attic, antique clock pendulums swing slowly in the blurred background, Grok's blonde twin-tail curls stir gently, glistening tears tremble at the corner of her ice-blue eyes as she takes a soft shaky breath, silent video.
