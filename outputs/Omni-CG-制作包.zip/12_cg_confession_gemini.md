# cg_confession_gemini

- assets/bg/cg_confession_gemini.webp

## Motion Prompt

5-second seamless anime CG loop from this exact illustration: floating holographic Gemini constellations rotate slowly and sparkle, brass armillary sphere rings turn smoothly in her hand, colorful fireworks burst gently over the night bay, breeze lifts her purple-pink hair and ribbons while strictly keeping viewer-left rose-pink and viewer-right gold eyes consistent, silent.
