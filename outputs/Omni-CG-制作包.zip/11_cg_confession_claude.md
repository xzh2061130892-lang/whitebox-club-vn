# cg_confession_claude

- assets/bg/cg_confession_claude.webp

## Motion Prompt

5-second seamless anime CG loop from this exact illustration: warm glasshouse candle flames flicker gently casting soft golden shimmer on the ginkgo leaves and poetry book, distant colorful fireworks glow softly through the Victorian glass dome behind her, Claude's copper-orange hair sways faintly, gentle affectionate blink and soft blush glow, keep intertwined hands steady, silent.
