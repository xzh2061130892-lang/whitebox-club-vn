# cg_prologue_404_chaos

- assets/sprites/gpt-1-front.webp
- assets/sprites/claude-1-front.webp
- assets/sprites/gemini-1-front.webp
- assets/sprites/grok-1-front.webp
- assets/sprites/deepseek-1-front.webp
- assets/bg/bg_room_404_day.webp
- assets/bg/cg_grand_404_photo.webp

## Static Prompt

Masterpiece commercial anime visual novel event CG illustration, 16:9 widescreen, bright afternoon sunlight streaming through arched wooden windows, matching the exact art style of cg_grand_404_photo.webp and the exact Room 404 layout of bg_room_404_day.webp with the absurdly luxurious crystal chandelier overhead and steaming white rice cooker on the right counter. Lively chaotic romantic-comedy group scene featuring all five heroines in their exact default outfits from the *-1-front.webp reference sheets: on the left crimson velvet window bench, honey-blonde twin-tail Grok with black bat-wing bows, tiny crown, ice-blue eyes and cute single fang sits cross-legged munching potato chips with her oversized black-and-gold X prop axe resting beside her, grinning mischievously; center-left, pearl-white haired dragon girl GPT with ridged ivory horns, small pale wings and white-scaled tail holds up a long chandelier installment receipt with an overly graceful encouraging smile; center, copper-orange wavy-haired Claude with sunburst hairpiece sternly slams a glowing gold-and-black "SUSPENDED" warning card onto the wooden table while protecting a tiny orange felt crab; center-right, blue-haired whale-girl DeepSeek with curved ahoge, lateral whale-fin ears and whale tail hugs a shiny stainless-steel bowl of steaming white rice defensively with a shocked blush; far-right corner, periwinkle-pink twin-bun cat-girl Gemini (viewer-left eye rose-pink, viewer-right eye gold heterochromia) with teary puppy eyes clutches a giant starry welcome banner with a tiny gold star sticker while stumbling toward a warning-taped paper shredder. Crisp anime lineart, vibrant cel-shading, dynamic comedic storytelling composition, no text overlays except the tiny card.

## Motion Prompt

Subtle lively anime cutscene loop, 5 seconds, smooth static medium-wide camera with gentle slow push-in: sunlight dust motes float down from the sparkling crystal chandelier, steam rises gently from the white rice cooker and rice bowl, Grok's legs swing playfully, GPT's pale wings flutter lightly, Gemini's cat ears twitch nervously, DeepSeek's curved ahoge wobbles, hair and ribbons sway softly in afternoon breeze, preserve exact character faces and outfits, silent video.
