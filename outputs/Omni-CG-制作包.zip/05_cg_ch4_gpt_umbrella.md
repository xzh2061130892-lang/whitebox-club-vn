# cg_ch4_gpt_umbrella

- assets/sprites/gpt-summer-front.webp
- assets/bg/bg_hydrangea_rain_walk.webp
- assets/bg/cg_confession_gpt.webp

## Static Prompt

Masterpiece commercial anime visual novel romantic event CG illustration, 16:9 widescreen, intimate first-person POV close-up matching the exact anime rendering style of cg_confession_gpt.webp. Standing beneath a shared translucent pale-lavender umbrella along a rain-kissed stone stairway lined with blooming blue and violet hydrangeas matching bg_hydrangea_rain_walk.webp, soft sunbeams breaking through post-rain clouds and illuminating sparkling raindrops falling off the umbrella rim. Matching exact character design and outfit from gpt-summer-front.webp: pearl-white wavy-haired dragon girl GPT with ridged ivory horns, silver panchang knot hairpin, pointed ears, small pale-lavender wings, white-scaled tail, sleeveless ruffled white chiffon blouse with lilac ribbon bow and pale-lilac high-waisted skirt with silver knot chains. She leans happily and closely against the viewer's arm (only the viewer's dark school uniform sleeve edge visible at the bottom-left foreground), holding the umbrella handle with one hand while hugging a thick cream notebook open to a page with a handwritten bold red "100" against her chest with her other arm, her lavender eyes glistening with joyful relieved tears and a radiant unguarded blush, water droplets sparkling on her sheer umbrella and petals.

## Motion Prompt

Romantic anime CG loop, 5 seconds, gentle steady POV framing: fine silvery rain slows to sparse sparkling drops sliding off the translucent lavender umbrella edge, warm golden sunbeams gradually brighten through wet hydrangea leaves, GPT's silver hair strands and lilac collar ribbons sway softly in the cool post-rain breeze, delicate glistening tears shimmer in her smiling lavender eyes, silent video.
