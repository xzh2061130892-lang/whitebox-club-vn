# cg_confession_deepseek

- assets/bg/cg_confession_deepseek.webp

## Motion Prompt

5-second seamless anime CG loop from this exact illustration: ocean waves glisten with colorful firework reflections and the distant harbor lighthouse beam rotates softly, sea breeze lifts DeepSeek's blue hair, curved ahoge, pearl shoulder chains and iridescent organza ruffles, her blue whale tail sways gently behind her, tender eye shimmer, silent.
